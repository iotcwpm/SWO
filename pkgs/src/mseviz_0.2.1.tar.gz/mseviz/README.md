# mseviz
- Version: 0.2.1
- Date: 2019-03-15
- Author: Iago Mosqueira, EC JRC.
- Maintainer: Iago Mosqueira, EC JRC.
- Repository: <https://github.com/iagomosqueira/mseviz/>
- Bug reports: <https://github.com/iagomosqueira/mseviz/issues>

## Overview
Plots and Visualization Tools for Management Strategy Evaluation Results

To install this package, start R and enter:

  library(devtools)
  install_github("iagomosqueira/mseviz")

## Documentation
- Help pages
- Vignette

## Build Status
[![Travis Build Status](https://travis-ci.org/iagomosqueira/mseviz.svg?branch=master)](https://travis-ci.org/iagomosqueira/mseviz)
[![AppVeyor Build Status](https://ci.appveyor.com/api/projects/status/github/iagomosqueira/mseviz?branch=master&svg=true)](https://ci.appveyor.com/project/iagomosqueira/mseviz)

## Releases
- [All releases](https://github.com/iagomosqueira/mseviz/releases/)

## License
Copyright (c) 2017-18 European Union. European Commission Joint Research Centre D.02. Released under the [EUPL 1.1](https://joinup.ec.europa.eu/community/eupl/og_page/eupl).

## Contact
You are welcome to:

- Submit suggestions and bug-reports at: <https://github.com/iagomosqueira/mseviz/issues>
- Send a pull request on: <https://github.com/iagomosqueira/mseviz/>
- Compose a friendly e-mail to: <iago.mosqueira@ec.europa.eu>
