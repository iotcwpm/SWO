
# FLCore
- Version: 2.6.9.9006
- Date: 2018-09-26
- Author: FLR Team and various [contributors](CONTRIBUTORS.md).
- Maintainer: Iago Mosqueira <iago.mosqueira@ec.europa.eu>
- Repository: <https://github.com/flr/FLCore/>
- Bug reports: <https://github.com/flr/FLCore/issues>

## Overview
FLCore contains the core classes and methods for FLR, a framework for fisheries modelling and management strategy simulation in R.

To install this package, start R and enter:

	install.packages("FLCore", repos="http://flr-project.org/R")

or download from the [FLR releases page](https://github.com/flr/R/releases)

## Documentation
- [Help pages](http://flr-project.org/FLCore)

## Bibliography

- Kell, L. T., I. Mosqueira, P. Grosjean, J-M. Fromentin, D. Garcia, R. Hillary, E. Jardim, S. Mardle, M. A. Pastoors, J. J. Poos, F. Scott, R. D. Scott. 2007. FLR: an open-source framework for the evaluation and development of management strategies. *ICES J Mar Sci*, 64 (4): 640-646. doi: [10.1093/icesjms/fsm012](https://doi.org/10.1093/icesjms/fsm012)

## Build Status
[![Travis Build Status](https://travis-ci.org/flr/FLCore.svg?branch=master)](https://travis-ci.org/flr/FLCore)
[![AppVeyor Build Status](https://ci.appveyor.com/api/projects/status/github/flr/FLCore?branch=master&svg=true)](https://ci.appveyor.com/project/flr/FLCore)
[![CRAN_Status_Badge](http://www.r-pkg.org/badges/version/FLCore)](https://cran.r-project.org/package=FLCore)

## Releases
- [Latest release](https://github.com/flr/R/releases/latest)
- [All releases](https://github.com/flr/R/releases/)

## License
Copyright (c) 2004-2017 The FLR Team. Released under the [GPL v2](http://www.gnu.org/licenses/gpl-2.0.html).

## Contact
You are welcome to:

- Submit suggestions and bug-reports at: <https://github.com/flr/FLCore/issues>
- Send a pull request on: <https://github.com/flr/FLCore/>
- Compose a friendly e-mail to: <flrteam@flr-project.org>
